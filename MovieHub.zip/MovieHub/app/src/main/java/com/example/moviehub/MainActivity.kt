package com.example.moviehub

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.view.WindowManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.reflect.KProperty

// ===== تنظیمات پاداش (برای تست سریع، REWARD_SEC را مثلاً 20 بگذارید) =====
const val REWARD_SEC = 900L      // هر ۱۵ دقیقه
const val REWARD_TOKENS = 1000L
const val VIDEO_URL = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

data class Movie(val id: Int, val title: String, val cat: String, val year: Int, val desc: String, val color: Color)

val cats = listOf("همه", "ترسناک", "هیجانی", "کمدی", "درام", "علمی‌تخیلی", "انیمیشن")
val movies = listOf(
    Movie(1, "شب خاموش", "ترسناک", 2023, "گروهی دوست در خانه‌ای متروک گرفتار می‌شوند.", Color(0xFF4A148C)),
    Movie(2, "سایه‌ها", "ترسناک", 2022, "رازی قدیمی در یک روستای دورافتاده بیدار می‌شود.", Color(0xFF311B92)),
    Movie(3, "تعقیب", "هیجانی", 2024, "یک کارآگاه در مسابقه‌ای نفس‌گیر با زمان.", Color(0xFFB71C1C)),
    Movie(4, "خط قرمز", "هیجانی", 2021, "عملیاتی پرخطر که هیچ‌کس نباید از آن باخبر شود.", Color(0xFFD84315)),
    Movie(5, "دورهمی", "کمدی", 2023, "یک مهمانی ساده که همه‌چیز را به هم می‌ریزد.", Color(0xFFF9A825)),
    Movie(6, "شانس آوردیم", "کمدی", 2020, "دو همسایه و یک سوءتفاهم بزرگ.", Color(0xFFEF6C00)),
    Movie(7, "خانه‌ی پدری", "درام", 2022, "بازگشت به خانه، بازگشت به خاطرات.", Color(0xFF00695C)),
    Movie(8, "فصل آخر", "درام", 2024, "داستان خانواده‌ای در آستانه‌ی تغییر.", Color(0xFF2E7D32)),
    Movie(9, "مدار صفر", "علمی‌تخیلی", 2025, "سفری به آن‌سوی زمان و مکان.", Color(0xFF1565C0)),
    Movie(10, "ستاره‌ی دور", "علمی‌تخیلی", 2023, "آخرین مأموریت یک فضانورد.", Color(0xFF0277BD)),
    Movie(11, "جنگل جادو", "انیمیشن", 2024, "ماجراجویی دوستان کوچک در جنگلی افسانه‌ای.", Color(0xFF6A1B9A)),
    Movie(12, "ماه‌پرواز", "انیمیشن", 2022, "پسری که می‌خواهد به ماه برسد.", Color(0xFFAD1457)),
)
val accents = listOf(0xFFE50914, 0xFF1E88E5, 0xFF43A047, 0xFF8E24AA, 0xFFFB8C00, 0xFF00ACC1, 0xFFD81B60, 0xFF6D4C41)
val notifTypes = listOf(
    "new" to "فیلم‌های جدید", "episode" to "قسمت جدید سریال‌های ذخیره‌شده",
    "reward" to "دریافت توکن", "offer" to "پیشنهادهای ویژه", "security" to "هشدارهای امنیتی",
)

// ===== ذخیره‌سازی ساده =====
class Pref<T : Any>(private val sp: SharedPreferences, private val k: String, d: T) {
    @Suppress("UNCHECKED_CAST")
    private var st by mutableStateOf(when (d) {
        is Long -> sp.getLong(k, d); is Boolean -> sp.getBoolean(k, d)
        is Int -> sp.getInt(k, d); else -> sp.getString(k, d as String)
    } as T)
    operator fun getValue(r: Any?, p: KProperty<*>): T = st
    operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
        st = v
        sp.edit().apply {
            when (v) {
                is Long -> putLong(k, v); is Boolean -> putBoolean(k, v)
                is Int -> putInt(k, v); else -> putString(k, v as String)
            }
        }.apply()
    }
}

class Store(c: Context) {
    private val sp = c.getSharedPreferences("app", 0)
    var tokens by Pref(sp, "tokens", 0L)
    var watchSec by Pref(sp, "watch", 0L)
    var loggedIn by Pref(sp, "in", false)
    var name by Pref(sp, "name", "")
    var phone by Pref(sp, "phone", "")
    var accounts by Pref(sp, "accounts", "")
    var verified by Pref(sp, "verified", false)
    var themeMode by Pref(sp, "theme", 0)
    var accent by Pref(sp, "accent", accents[0].toInt())
    var amoled by Pref(sp, "amoled", false)
    var notifs by Pref(sp, "notifs", "new,episode,reward,security")
    var savedIds by Pref(sp, "saved", "")
    var pinOn by Pref(sp, "pinOn", false)
    var pin by Pref(sp, "pin", "")
    var twoStep by Pref(sp, "twoStep", false)
    var secureScreen by Pref(sp, "secure", false)

    /** هر ثانیه پخش یک‌بار صدا زده می‌شود؛ اگر پاداش داده شد true برمی‌گرداند */
    fun tick(): Boolean {
        watchSec += 1
        if (watchSec % REWARD_SEC == 0L) { tokens += REWARD_TOKENS; return true }
        return false
    }
}

fun has(s: String, k: String) = s.split(",").contains(k)
fun toggle(s: String, k: String) = s.split(",").filter { it.isNotEmpty() }.let { if (k in it) it - k else it + k }.joinToString(",")

fun validNationalCode(c: String): Boolean {
    if (!Regex("\\d{10}").matches(c) || c.all { it == c[0] }) return false
    val r = (0..8).sumOf { (c[it] - '0') * (10 - it) } % 11
    val k = c[9] - '0'
    return if (r < 2) k == r else k == 11 - r
}
fun validPhone(p: String) = Regex("^09\\d{9}$").matches(p)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent { App(store) }
    }
}

@Composable
fun App(st: Store) {
    val dark = when (st.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val acc = Color(st.accent)
    val scheme = if (dark) {
        if (st.amoled) darkColorScheme(primary = acc, background = Color.Black, surface = Color.Black)
        else darkColorScheme(primary = acc)
    } else lightColorScheme(primary = acc)
    val act = LocalContext.current as Activity
    LaunchedEffect(st.secureScreen) {
        if (st.secureScreen) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                var unlocked by remember { mutableStateOf(!st.pinOn) }
                when {
                    !unlocked -> PinScreen(st) { unlocked = true }
                    !st.loggedIn -> LoginScreen(st)
                    else -> MainScreen(st)
                }
            }
        }
    }
}

@Composable
fun PinScreen(st: Store, onOk: () -> Unit) {
    var v by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("رمز ورود را وارد کنید", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(v, { if (it.length <= 4) v = it; if (it.length == 4 && it == st.pin) onOk() },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            isError = v.length == 4 && v != st.pin, singleLine = true, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
fun LoginScreen(st: Store) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    fun login(n: String, p: String) {
        st.name = n; st.phone = p; st.loggedIn = true
        if (!st.accounts.split(";").contains("$n|$p")) st.accounts = (st.accounts.split(";").filter { it.isNotEmpty() } + "$n|$p").joinToString(";")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(32.dp))
        Text("به مووی‌هاب خوش آمدید", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        st.accounts.split(";").filter { it.isNotEmpty() }.forEach { a ->
            val (n, p) = a.split("|")
            OutlinedCard(Modifier.fillMaxWidth().clickable { login(n, p) }) {
                ListItem(headlineContent = { Text(n) }, supportingContent = { Text(p) }, leadingContent = { Icon(Icons.Default.AccountCircle, null) })
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text("نام کاربری") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("شماره تماس (09...)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        Button({
            if (name.isBlank() || !validPhone(phone)) Toast.makeText(ctx, "نام و شماره معتبر وارد کنید", Toast.LENGTH_SHORT).show()
            else login(name.trim(), phone)
        }, Modifier.fillMaxWidth()) { Text("ورود / ساخت حساب") }
    }
}

@Composable
fun MainScreen(st: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<Movie?>(null) }
    BackHandler(playing != null) { playing = null }
    val m = playing
    if (m != null) { PlayerScreen(st, m) { playing = null }; return }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("خانه" to Icons.Default.Home, "کیف پول" to Icons.Default.AccountBalanceWallet, "حساب کاربری" to Icons.Default.Person)
                .forEachIndexed { i, (t, ic) ->
                    NavigationBarItem(tab == i, { tab = i }, { Icon(ic, null) }, label = { Text(t) })
                }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> HomeScreen(st) { playing = it }; 1 -> WalletScreen(st); else -> ProfileScreen(st) }
        }
    }
}

@Composable
fun HomeScreen(st: Store, onPlay: (Movie) -> Unit) {
    var cat by remember { mutableStateOf("همه") }
    val list = movies.filter { cat == "همه" || it.cat == cat }
    Column(Modifier.fillMaxSize()) {
        Text("مووی‌هاب", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> FilterChip(cat == c, { cat = c }, { Text(c) }) }
        }
        LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { m ->
                val saved = has(st.savedIds, m.id.toString())
                Box(Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(16.dp)).background(m.color).clickable { onPlay(m) }) {
                    IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }, Modifier.align(Alignment.TopStart)) {
                        Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Color.White)
                    }
                    Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(48.dp), tint = Color.White.copy(alpha = .8f))
                    Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                        Text(m.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${m.cat} • ${m.year}", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(st: Store, m: Movie, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(VIDEO_URL)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (exo.isPlaying && st.tick()) Toast.makeText(ctx, "🎉 $REWARD_TOKENS توکن دریافت کردید", Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(m.title, style = MaterialTheme.typography.titleLarge)
        }
        AndroidView({ c -> PlayerView(c).also { it.player = exo } }, Modifier.fillMaxWidth().aspectRatio(16 / 9f))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${m.cat} • ${m.year}", color = MaterialTheme.colorScheme.primary)
            Text(m.desc)
            Spacer(Modifier.height(8.dp))
            Text("تا پاداش بعدی", style = MaterialTheme.typography.labelLarge)
            LinearProgressIndicator(progress = { (st.watchSec % REWARD_SEC) / REWARD_SEC.toFloat() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun WalletScreen(st: Store) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("کیف پول", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(24.dp)) {
                Text("مجموع توکن‌های دریافت‌شده")
                Text("%,d".format(st.tokens), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("تعداد پاداش‌ها", "${st.watchSec / REWARD_SEC}", Modifier.weight(1f))
            StatCard("زمان تماشا (دقیقه)", "${st.watchSec / 60}", Modifier.weight(1f))
        }
        Text("با هر ${REWARD_SEC / 60} دقیقه تماشا، $REWARD_TOKENS توکن دریافت می‌کنید.")
        LinearProgressIndicator(progress = { (st.watchSec % REWARD_SEC) / REWARD_SEC.toFloat() }, Modifier.fillMaxWidth())
        Text("${REWARD_SEC - st.watchSec % REWARD_SEC} ثانیه تا پاداش بعدی", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StatCard(t: String, v: String, mod: Modifier) = OutlinedCard(mod) {
    Column(Modifier.padding(16.dp)) { Text(t, style = MaterialTheme.typography.bodySmall); Text(v, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
}

@Composable
fun NavRow(icon: ImageVector, title: String, sub: String? = null, onClick: () -> Unit) = ListItem(
    headlineContent = { Text(title) },
    supportingContent = if (sub != null) ({ Text(sub) }) else null,
    leadingContent = { Icon(icon, null) },
    trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null) },
    modifier = Modifier.clickable(onClick = onClick))

@Composable
fun SwitchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) = ListItem(
    headlineContent = { Text(title) }, trailingContent = { Switch(on, onChange) })

@Composable
fun SubPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        content()
    }
}

@Composable
fun ProfileScreen(st: Store) {
    var sub by remember { mutableStateOf("") }
    val back = { sub = "" }
    when (sub) {
        "kyc" -> SubPage("احراز هویت", back) { Kyc(st) }
        "notif" -> SubPage("اعلان‌ها", back) {
            notifTypes.forEach { (k, t) -> SwitchRow(t, has(st.notifs, k)) { st.notifs = toggle(st.notifs, k) } }
        }
        "security" -> SubPage("امنیت", back) { Security(st) }
        "theme" -> SubPage("تنظیمات ظاهری", back) { Appearance(st) }
        "saved" -> SubPage("فیلم‌های ذخیره‌شده", back) {
            val l = movies.filter { has(st.savedIds, it.id.toString()) }
            if (l.isEmpty()) Text("هنوز فیلمی ذخیره نکرده‌اید.", Modifier.padding(16.dp))
            l.forEach { m ->
                ListItem(headlineContent = { Text(m.title) }, supportingContent = { Text(m.cat) },
                    leadingContent = { Box(Modifier.size(40.dp).clip(CircleShape).background(m.color)) },
                    trailingContent = { IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }) { Icon(Icons.Default.Delete, null) } })
            }
        }
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(st.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(st.phone)
                    Text(if (st.verified) "هویت تأییدشده ✅" else "هویت تأیید نشده", style = MaterialTheme.typography.bodySmall)
                }
            }
            HorizontalDivider()
            NavRow(Icons.Default.VerifiedUser, "احراز هویت", if (st.verified) "تأیید شده" else "تأیید نشده") { sub = "kyc" }
            NavRow(Icons.Default.Notifications, "اعلان‌ها") { sub = "notif" }
            NavRow(Icons.Default.Lock, "امنیت") { sub = "security" }
            NavRow(Icons.Default.Palette, "تنظیمات ظاهری") { sub = "theme" }
            NavRow(Icons.Default.Bookmarks, "فیلم‌های ذخیره‌شده", "${st.savedIds.split(",").count { it.isNotEmpty() }} مورد") { sub = "saved" }
            HorizontalDivider()
            NavRow(Icons.Default.PersonAdd, "افزودن حساب") { st.loggedIn = false }
            NavRow(Icons.AutoMirrored.Filled.Logout, "خروج از حساب") { st.loggedIn = false }
        }
    }
}

@Composable
fun Kyc(st: Store) {
    val ctx = LocalContext.current
    var nc by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf(st.phone) }
    var sent by remember { mutableStateOf(false) }
    var otp by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (st.verified) { Text("هویت شما با موفقیت تأیید شده است ✅"); return@Column }
        Text("کد ملی باید به نام صاحب همین شماره تماس باشد.")
        OutlinedTextField(nc, { nc = it.take(10) }, label = { Text("کد ملی") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ph, { ph = it.take(11) }, label = { Text("شماره تماس") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (!sent) {
            Button({
                err = when {
                    !validNationalCode(nc) -> "کد ملی معتبر نیست"
                    !validPhone(ph) -> "شماره تماس معتبر نیست"
                    else -> null
                }
                // TODO: اینجا باید سرویس استعلام تطبیق کد ملی و شماره (مثل شاهکار از طریق ارائه‌دهنده‌ی مجاز) صدا زده شود
                if (err == null) { sent = true; Toast.makeText(ctx, "کد دمو: 12345", Toast.LENGTH_LONG).show() }
            }, Modifier.fillMaxWidth()) { Text("ارسال کد تأیید") }
        } else {
            OutlinedTextField(otp, { otp = it.take(5) }, label = { Text("کد پیامک‌شده") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Button({ if (otp == "12345") st.verified = true else err = "کد اشتباه است" }, Modifier.fillMaxWidth()) { Text("تأیید هویت") }
        }
    }
}

@Composable
fun Security(st: Store) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf(false) }
    var p by remember { mutableStateOf("") }
    SwitchRow("قفل برنامه با رمز ۴ رقمی", st.pinOn) { if (it) { p = ""; dialog = true } else { st.pinOn = false; st.pin = "" } }
    if (st.pinOn) NavRow(Icons.Default.Password, "تغییر رمز") { p = ""; dialog = true }
    SwitchRow("تأیید دو مرحله‌ای (پیامک)", st.twoStep) { st.twoStep = it }
    SwitchRow("جلوگیری از اسکرین‌شات و ضبط صفحه", st.secureScreen) { st.secureScreen = it }
    NavRow(Icons.Default.Devices, "خروج از سایر دستگاه‌ها") { Toast.makeText(ctx, "از سایر دستگاه‌ها خارج شدید", Toast.LENGTH_SHORT).show() }
    if (dialog) AlertDialog(onDismissRequest = { dialog = false }, title = { Text("رمز ۴ رقمی جدید") },
        text = {
            OutlinedTextField(p, { p = it.filter(Char::isDigit).take(4) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        },
        confirmButton = { TextButton({ if (p.length == 4) { st.pin = p; st.pinOn = true; dialog = false } }) { Text("ذخیره") } },
        dismissButton = { TextButton({ dialog = false }) { Text("انصراف") } })
}

@Composable
fun Appearance(st: Store) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حالت نمایش", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("سیستم", "روشن", "تیره").forEachIndexed { i, t -> FilterChip(st.themeMode == i, { st.themeMode = i }, { Text(t) }) }
        }
        Text("رنگ اصلی برنامه", style = MaterialTheme.typography.titleMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(accents) { c ->
                val col = Color(c)
                Box(Modifier.size(44.dp).clip(CircleShape).background(col).clickable { st.accent = col.toArgb() },
                    contentAlignment = Alignment.Center) {
                    if (st.accent == col.toArgb()) Icon(Icons.Default.Check, null, tint = Color.White)
                }
            }
        }
        SwitchRow("پس‌زمینه‌ی کاملاً مشکی (AMOLED) در حالت تیره", st.amoled) { st.amoled = it }
    }
}
