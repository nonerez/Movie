1) Android Studio (Koala یا جدیدتر) > Open > پوشه‌ی MovieHub
2) صبر کنید Gradle Sync تمام شود
3) Run روی گوشی یا شبیه‌ساز
4) خروجی APK: Build > Build APK(s)
برای تست سریع پاداش، REWARD_SEC در MainActivity.kt را مثلاً 20 بگذارید.
